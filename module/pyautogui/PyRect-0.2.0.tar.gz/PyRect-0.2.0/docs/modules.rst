pyrect
======

.. toctree::
   :maxdepth: 4

   pyrect
